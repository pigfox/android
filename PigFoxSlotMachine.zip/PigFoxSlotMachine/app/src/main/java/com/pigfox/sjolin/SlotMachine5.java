/* By Peter Sjolin, Senior El Presidente, Pigfox.com */
package com.pigfox.sjolin;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class SlotMachine5 extends Activity
{	
	int returnSymbol;
	
	int []imageArray={R.drawable.s1,R.drawable.s2,R.drawable.s3,R.drawable.s4,R.drawable.s5,R.drawable.s6,R.drawable.s7,R.drawable.s8,R.drawable.s9};
	int []idArray={R.id.wheel1, R.id.wheel2, R.id.wheel3};
	
	public static final int ARRAY_INDEX_MAX = 4;
	
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {    	
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.main);
    	
    	final Button playButton = (Button) findViewById(R.id.playButton); 
		
		final ImageView[] wheelView = new ImageView[4];// Not using ImageView[0]
		wheelView[0] = null;
		
		for(int i = 1; i < ARRAY_INDEX_MAX; i++)
		{
			wheelView[i] = (ImageView) findViewById(idArray[i-1]);
			wheelView[i].setImageResource(imageArray[(int) (Math.random() * imageArray.length)]);
		}
		
		class PlayMGR
		{
			int wheel1value, wheel2value, wheel3value;
			
			PlayMGR()
			{
				this.wheel1value = -1;
				this.wheel2value = -1;
				this.wheel3value = -1;				
			}
			
			public void setValues(int wheelNum, int score)
			{
				if(wheelNum == 1)
					wheel1value = score;
				if(wheelNum == 2)
					wheel2value = score;
				if(wheelNum == 3)
					wheel3value = score;
				
				if(-1 < wheel1value && -1 < wheel2value && -1 < wheel3value)
				{
					if(wheel1value == wheel2value && wheel2value == wheel3value)
						Toast.makeText(SlotMachine5.this, "You Win!!!", Toast.LENGTH_SHORT).show();
					else if(wheel1value == wheel2value || wheel1value == wheel3value || wheel2value == wheel3value)
						Toast.makeText(SlotMachine5.this, "You won two of a kind.", Toast.LENGTH_SHORT).show();
					else
						Toast.makeText(SlotMachine5.this, "Sorry, you lost, please try again.", Toast.LENGTH_SHORT).show();
					
					playButton.setText("Play Again");					
					playButton.setEnabled(true); 
					
					return;
				}				
			}
		}

		playButton.setOnClickListener(new View.OnClickListener() 
        {
            public void onClick(View view) 
            {
            	playButton.setEnabled(false);
            	
            	final PlayMGR playMGR = new PlayMGR();
          	           	
            	final Handler[] handlers = new Handler[4];// Not using handlers[0]
            	handlers[0] = null;
            	
            	for(int j = 1; j < ARRAY_INDEX_MAX; j++)
            	{
            		try{
            			handlers[j] = new Handler();
            		}
            		catch(Exception e){
            			Log.e(Integer.toString(j), e.toString());
            		}
            	}

            	class Wheel implements Runnable
            	{	 
					int count, spins, wheelNum, postDelay, wheelPos;
					
					Wheel(int w)
					{
						this.count = 0;
						this.wheelPos = 0;
						this.wheelNum = w;
						this.spins = (int) ( (Math.random() * 100) + (Math.random() * 10) + Math.random());
						this.postDelay = (int) Math.random();
					}
					 
					public void run() 
					{												
						wheelPos = (int) (imageArray.length *  Math.random());						
						
						wheelView[wheelNum].setImageResource(imageArray[wheelPos]);
					  
						count++;
						
						if(count == spins || count == 1000)
						{
							playMGR.setValues(wheelNum, wheelPos);
							return;
						}
												
						handlers[wheelNum].postDelayed(this, postDelay);
						
						synchronized(this){
							try {
								wait(25);
							} catch(Exception e){
		            			Log.e("Wait", e.toString());					
							}
						}
					}
            	};
            	
            	for(int j = 1; j < ARRAY_INDEX_MAX; j++)
            	{
            		try{
            			handlers[j].postDelayed(new Wheel(j), 2);
            		}
            		catch(Exception e){
            			Log.e(Integer.toString(j), e.toString());
            		}            		
            	}	

        		return;
            }//onClick
        });//playButton.setOnClickListener
    }//onCreate    
}//class